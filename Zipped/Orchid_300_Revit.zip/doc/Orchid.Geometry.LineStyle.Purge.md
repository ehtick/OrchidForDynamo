﻿## In Depth  
Purges all line styles in document that is not in use!  

**Example**  
![Illustration](./Orchid.Geometry.LineStyle.Purge.png)
**WebSite**  
[Github](https://github.com/erfajo/OrchidForDynamo) -- [Issues](https://github.com/erfajo/OrchidForDynamo/issues) -- [Samples](https://github.com/erfajo/OrchidForDynamo/tree/master/Samples) -- [Blog](https://erfajo.blogspot.com)
